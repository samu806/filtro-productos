
const products = [
    { id: 1, name: 'Camiseta', category: 'ropa', price: 'bajo', image: 'https://via.placeholder.com/200' },
    { id: 2, name: 'Pantalón', category: 'ropa', price: 'medio', image: 'https://via.placeholder.com/200' },
    { id: 3, name: 'Zapatos', category: 'calzado', price: 'alto', image: 'https://via.placeholder.com/200' },
    { id: 4, name: 'Sombrero', category: 'accesorios', price: 'bajo', image: 'https://via.placeholder.com/200' },
    { id: 5, name: 'Bufanda', category: 'accesorios', price: 'medio', image: 'https://via.placeholder.com/200' },
    { id: 6, name: 'Chaqueta', category: 'ropa', price: 'alto', image: 'https://via.placeholder.com/200' }
];

const modal = document.getElementById('modal');
const openFiltersButton = document.getElementById('openFilters');
const closeModalButton = document.getElementById('closeModal');
const filtersForm = document.getElementById('filtersForm');
const productList = document.getElementById('productList');
const clearFiltersButton = document.getElementById('clearFilters');

// Abrir y cerrar el modal de filtros
openFiltersButton.addEventListener('click', () => {
    modal.style.display = 'flex';
});
closeModalButton.addEventListener('click', () => {
    modal.style.display = 'none';
});

// Filtrar productos
filtersForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const category = document.getElementById('category').value;
    const price = document.getElementById('price').value;

    const filteredProducts = products.filter(product => {
        return (
            (category ? product.category === category : true) &&
            (price ? product.price === price : true)
        );
    });

    if (filteredProducts.length === 0) {
        productList.innerHTML = '<p>No se encontraron productos. Mostrando productos sugeridos:</p>';
        renderProducts(products.sort(() => 0.5 - Math.random()).slice(0, 3));  // Productos aleatorios
    } else {
        renderProducts(filteredProducts);
    }

    modal.style.display = 'none';  // Cerrar el modal después de aplicar los filtros
});

// Limpiar filtros
clearFiltersButton.addEventListener('click', () => {
    document.getElementById('category').value = '';
    document.getElementById('price').value = '';
    renderProducts(products);  // Mostrar todos los productos
});

// Renderizar productos
function renderProducts(productsToRender) {
    productList.innerHTML = '';  // Limpiar la lista de productos
    productsToRender.forEach(product => {
        const productElement = document.createElement('div');
        productElement.classList.add('product');
        productElement.innerHTML = `
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>Precio: ${product.price}</p>
        `;
        productList.appendChild(productElement);
}

// Inicializar la lista de productos
renderProducts(products);
